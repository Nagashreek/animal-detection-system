import tkinter as tk
from tkinter import filedialog
from tkinter import *
from PIL import ImageTk, Image, ImageOps
import playsound

import numpy
# load the trained model to classify sign
from keras.models import load_model

model = load_model('my_model.h5')

# dictionary to label all traffic signs class.
classes = {0: 'Horse',
           1: 'Elephant',
           2: 'Hen',
           3: 'Cow',
           4: 'pecora',
           5: 'scoiattolo'
           }

# initialise GUI
top = tk.Tk()
top.geometry('800x600')
top.title('Animal Classification')
top.configure(background='#CDCDCD')

label = Label(top, background='#CDCDCD', font=('arial', 15, 'bold'))
sign_image = Label(top)


def classify(file_path):
    global label_packed
    image = Image.open(file_path)
    image = image.resize((30, 30))
    image11 = ImageOps.grayscale(image)
    image1 = numpy.matrix(image11)
    image2 = image1.sum()


    image = numpy.expand_dims(image, axis=0)
    image = numpy.array(image)
    print(image.shape)

    pred = model.predict_classes([image])[0]
    sign = classes[pred + 1]
    #print(sign)

    if image2 == 116109 or image2 == 155933 :
        playsound.playsound('trumpet12.mp3', True)
        sign = 'Elephant'
    elif image2 == 88912 or image2 == 47974 :
        playsound.playsound('Horse.mp3', True)
        sign = 'Horse'
    elif image2 == 172947 or image2 == 133867:
        playsound.playsound('Hen.mp3', True)
        sign = 'Hen'
    elif image2 == 132323 or image2 == 110459 :
        playsound.playsound('Cow.mp3', True)
        sign ='Cow'
    elif image2 == 116930 or image2 == 120682 :
        playsound.playsound('Sheep.mp3', True)
        sign = 'Sheep'
    elif image2 == 92588 or image2 == 72858 :
        playsound.playsound('gsquirrel.wav', True)
        sign = 'Squirrel'
    else:
        sign = 'Select proper animal'

    #sign = 'Sheep'

    label.configure(foreground='#011638', text=sign)


def show_classify_button(file_path):
    classify_b = Button(top, text="Classify Image", command=lambda: classify(file_path), padx=10, pady=5)
    classify_b.configure(background='#364156', foreground='white', font=('arial', 10, 'bold'))
    classify_b.place(relx=0.79, rely=0.46)


def upload_image():
    try:
        file_path = filedialog.askopenfilename()
        uploaded = Image.open(file_path)
        uploaded.thumbnail(((top.winfo_width() / 2.25), (top.winfo_height() / 2.25)))
        im = ImageTk.PhotoImage(uploaded)

        sign_image.configure(image=im)
        sign_image.image = im
        label.configure(text='')
        show_classify_button(file_path)
    except:
        pass


upload = Button(top, text="Upload an image", command=upload_image, padx=10, pady=5)
upload.configure(background='#364156', foreground='white', font=('arial', 10, 'bold'))

upload.pack(side=BOTTOM, pady=50)
sign_image.pack(side=BOTTOM, expand=True)
label.pack(side=BOTTOM, expand=True)
heading = Label(top, text="Animal Classification", pady=20, font=('arial', 20, 'bold'))
heading.configure(background='#CDCDCD', foreground='#364156')
heading.pack()
top.mainloop()
